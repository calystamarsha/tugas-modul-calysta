/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kuis__51022004;
import java.net.Socket;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Scanner;


public class ClientLaundry {
    String host = "localhost";
    int nomorport = 5554;
    DataInputStream terima;
    DataOutputStream kirim;
    String tipelaundry,waktulaundry,total;
    
    public ClientLaundry(String nama, String nohp, String berat, String tipe,String waktu){
        try {
            Socket socket = new Socket(host, nomorport);
            kirim = new DataOutputStream(socket.getOutputStream());
            terima = new DataInputStream(socket.getInputStream());

            kirim.writeUTF(nama);
            kirim.writeUTF(nohp);
            kirim.writeUTF(berat);
            kirim.writeUTF(tipe);
            kirim.writeUTF(waktu);
            
            
            tipelaundry = terima.readUTF();
            waktulaundry = terima.readUTF();
            total = terima.readUTF();

            
        } catch (IOException e) {
            System.out.println(e);
        }
    
        
    }
    
    public String gettipelaundry(){
        return(tipelaundry);
    }
    public String getwaktulaundry(){
        return(waktulaundry);
    }
    public String gettotal(){
        return(total);
    }
}