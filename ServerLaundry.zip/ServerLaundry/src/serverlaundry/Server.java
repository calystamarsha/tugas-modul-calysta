
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package serverlaundry;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author ASUS
 */
public class Server {
     ServerSocket server;
    int nomorport=5554;
    Socket socket;
    DataInputStream terima;
    DataOutputStream kirim;
    
    public Server(){
        try{
        System.out.println("Server dijalankan di port "+nomorport);
        server=new ServerSocket(nomorport);
        while (true) {
        System.out.println("Server menunggu koneksi client...");
        socket=server.accept();
        System.out.println("Ada client terkoneksi...");
        kirim = new DataOutputStream(socket.getOutputStream());
        terima = new DataInputStream(socket.getInputStream());

        String nama=terima.readUTF();
        String nohp=terima.readUTF();
        int kg=Integer.parseInt(terima.readUTF());
        String tipelaundryTF=terima.readUTF();
        String waktulaundryTF = terima.readUTF();
        int tipelaundry, waktulaundry;

        if (tipelaundryTF.equals("Complete")) {
            tipelaundry= 9500 * kg;
        } else {
        tipelaundry= 6500 * kg;
        }


        if (waktulaundryTF.equals("Express")) {
            waktulaundry = 5000 * kg;
        } else {
            waktulaundry = 0;
        }

        int total = tipelaundry + waktulaundry;


        
        SimpanData s = new SimpanData();
        s.Simpan(nama,nohp,String.valueOf(kg),tipelaundryTF,waktulaundryTF,String.valueOf(tipelaundry),String.valueOf(waktulaundry),String.valueOf(total));
        
        kirim.writeUTF(String.valueOf (tipelaundry));
        kirim.writeUTF(String.valueOf (waktulaundry));
        kirim.writeUTF(String.valueOf (total));
    }
        }catch(IOException e){
        System.out.println(e);

} 
}
}

