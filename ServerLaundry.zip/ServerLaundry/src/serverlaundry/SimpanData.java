/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package serverlaundry;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author ASUS
 */
    public class SimpanData {
    public void Simpan(String nama,String nohp,String berat,String tipe,String waktu,String biayatipe, String biayawaktu,String total) {
    try {
            File file = new File("topcleanlaundry.dat");
            BufferedWriter output = new BufferedWriter(new FileWriter(file, true));
            String data=nama+":"+nohp+":"+berat+":"+tipe+":"+":"+waktu+":"+biayatipe+":"+biayawaktu+":"+total+"\n";

            output.write(data);

            output.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void ReadShow() {
        String line;
        try {
            File file = new File("topcleanlaundry.dat");
            BufferedReader input = new BufferedReader(new FileReader(file));

            while ((line = input.readLine()) != null) {
                System.out.println(line);
            }
            input.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

 
}

